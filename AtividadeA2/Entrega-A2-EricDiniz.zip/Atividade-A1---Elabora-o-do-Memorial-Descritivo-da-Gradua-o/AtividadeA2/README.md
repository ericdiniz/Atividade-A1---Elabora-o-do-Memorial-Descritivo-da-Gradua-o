# Fichamentos

Este diretório mantém os fichamentos de artigos produzidos pelos alunos durante a execução do trabalho de  conclusão de curso. Nesta página inicial, o aluno deve apresentar a lista de artigos relacionados ao trabalho, incluindo o link dos fichamentos produzidos.
