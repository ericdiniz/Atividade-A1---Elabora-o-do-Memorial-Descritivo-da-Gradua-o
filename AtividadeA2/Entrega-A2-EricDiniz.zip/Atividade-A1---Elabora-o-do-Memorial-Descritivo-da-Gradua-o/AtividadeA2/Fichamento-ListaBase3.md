# Characterizing High-Quality Test Methods: A First Empirical Study

VELOSO, Victor; HORA, Andre. Characterizing high-quality test methods: a first empirical study. In: Proceedings of the 19th International Conference on Mining Software Repositories. 2022. p. 265-269.

## 1. Fichamento de Conteúdo

A prática de testes de software é fundamental no desenvolvimento, e a qualidade dos testes é frequentemente avaliada por métricas como cobertura de código. No entanto, essas métricas costumam considerar apenas a suíte de testes como um todo, mascarando a qualidade de métodos individuais. Para investigar essa lacuna, o artigo apresenta um estudo empírico baseado na técnica de *mutation testing*, aplicada especificamente no nível de métodos. Os autores estenderam a ferramenta *PIT* para analisar 18.321 métodos de teste em cinco projetos *open-source* Java (*RxJava, OkHttp, Retrofit, ZXing, Apache Commons Lang*). A metodologia incluiu a coleta de métricas estáticas (linhas de código, número de *asserts*, nomeação) e históricas (quantidade de modificações ao longo do tempo), além da detecção automatizada de *test smells*, classificados como críticos ou não críticos. Essa abordagem quantitativa permitiu comparar métodos de alta e baixa qualidade, identificando padrões de manutenção e confiabilidade. Os resultados mostraram que, embora métricas estáticas não diferenciem fortemente os métodos, a presença de determinados *test smells* críticos afeta mais intensamente os de baixa qualidade. Assim, o estudo fornece evidências de que indicadores de test smells são mais eficazes do que métricas tradicionais, como número de linhas de código, quantidade de asserts ou frequência de modificações, para avaliar a capacidade de testes detectarem *bugs*.

## 2. Fichamento Bibliográfico

* **Mutation Testing:** Uma técnica empregada para avaliar a eficácia dos testes, onde falhas artificiais (mutações) são inseridas no código para verificar se os testes existentes conseguem detectá-las. Se os testes falham em "matar" essas mutações, há uma indicação de que eles podem não ser eficazes na identificação de *bugs* reais.
* **Mutation Score:** É uma métrica que representa a proporção de mutantes detectados (mortos) em relação ao número total de mutantes gerados. Um mutante é considerado "morto" quando pelo menos um método de teste falha ao ser executado nele, seja por uma falha de asserção, um erro ou um *time-out*.
* **Test Method Mutation:** Uma abordagem focada em avaliar a qualidade de métodos de teste individualmente, ao invés da suíte de testes completa. Um *mutation score* é calculado para cada método de teste, baseado na proporção de mutantes mortos por aquele teste em particular sobre o total de mutantes que ele cobre. Essa granularidade mais fina ajuda a identificar a qualidade de testes específicos que podem ser ofuscados por um *score* geral elevado.
* **Test Smells:** Descrevem escolhas de design subótimas feitas durante o desenvolvimento de testes, que podem prejudicar a compreensibilidade e a manutenibilidade das suítes de teste. O estudo identifica alguns *test smells* como críticos (e.g., Sleepy Tests, General Fixture, Unknown Test), que se mostram mais prevalentes em métodos de baixa qualidade.
* **Métodos de Teste de Alta e Baixa Qualidade:** São categorizados no estudo com base em seus *mutation scores* individuais, selecionando os 100 melhores e os 100 piores. A pesquisa busca entender as características que os diferenciam, concluindo que a ausência de *test smells* críticos é um marcador mais relevante para a alta qualidade do que métricas de código ou evolutivas.

## 3. Fichamento de Citações

* "To assess the quality of a test suite, one can rely on mutation testing, which computes whether the overall test cases are adequately exercising the covered lines. However, this high level of granularity may overshadow the quality of individual test methods."
* "This technique injects mutations (artificial faults) into the code and checks if tests can detect (or “kill”, in the mutation testing terminology) these mutations. The rationale is that if it fails to detect such mutations, it will miss real bugs."
* "Overall, we find no major differences between high and low-quality test methods in terms of size, number of asserts, and modifications."
* "Thus, the 100% mutation score neglects quality difference between the test methods, from the mutation analysis perspective."
* "A mutant is “killed” when at least one of the test results differs between both sets, i.e., when at least one of the test methods run on the mutants failed, meaning they properly detected the code mutations."
* "In contrast, high-quality test methods are less affected by critical test smells."
